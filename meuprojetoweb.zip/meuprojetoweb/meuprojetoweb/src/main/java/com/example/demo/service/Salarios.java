package com.example.demo.service;

import com.example.demo.controller.GeradorDeSalarios;
import jakarta.ws.rs.core.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

//ser do tipo rest = se comunica com o mundo externo
@RestController
public class Salarios
{

    @Autowired
    private GeradorDeSalarios geraSalarios;

    @ResponseBody
    //isso é falar que quando o ususario digitar http no MEU local
    //host ele vai fazer uma busca de consulta (por isso o Get)
    @RequestMapping(method = RequestMethod.GET,
    path = "Salario-programado", produces = MediaType.APPLICATION_JSON)
    //QUANDO PEDIR NO GET ELE DEVOLVE ESSEPRODUTO AE EM CIMA DO TIPO JSON
    public ResponseEntity<?> getSalarioProgramador() {
        return new ResponseEntity<>(geraSalarios.SalarioProgramador(), HttpStatus.OK);
    }
}
