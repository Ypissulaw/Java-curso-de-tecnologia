package com.example.demo.controller;

import com.example.demo.entity.Salarios;
import org.springframework.stereotype.Controller;

import java.math.BigDecimal;


@Controller
public class GeradorDeSalarios {

    public BigDecimal SalarioProgramador(){
        Salarios SalarioProgramador = new Salarios();
        SalarioProgramador.setMeuSalarioDeProgramador(new BigDecimal( "50,00"));


        return SalarioProgramador.getMeuSalarioDeProgramador();
    }
}
