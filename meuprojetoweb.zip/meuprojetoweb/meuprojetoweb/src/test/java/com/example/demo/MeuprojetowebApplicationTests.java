package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.swing.*;
import java.math.BigDecimal;

@SpringBootTest
class MeuprojetowebApplicationTests {
	private BigDecimal meusalario = new BigDecimal("1000");

	@Test
	void contextLoads() {
		System.out.println("comecando o debug");
		System.out.println("Slario minimo ae: " + meusalario);
		System.out.println("debug acaba aqui :D");
	}

}
